/*
 * sprite.js
 *
 */
 
 function Sprite(x,y,c,n) {
   this.name = n;
   this.x = x;
   this.y = y;
   this.size = 60;   // this int may vary
   this.speed = SPEED;
   this.shoot_speed = RATE;
   this.vel_x = 0; //velocity
   this.vel_y = 0;
   this.colour = c;
   this.onPlatform = false; // check when sprite is on top of a platform
   this.layers = new Array();
   this.buffSelected = false;
   
   this.setup = function() {  //setup the sprite layers
      this.layers[0] = randomColour(); //outermost layer
      this.layers[1] = randomColour();
      this.layers[2] = randomColour();
      this.layers[3] = randomColour();
      this.layers[4] = randomColour();
      this.layers[5] = this.colour; //innermost layer
   }
   
   this.layerBuff = function () {   // buff gives player an extra layer
      this.layers.splice(0,0,randomColour());
      this.buffSelected = true;
   }
   
   this.shootBuff = function () {   // lets player shoot faster
      this.shoot_speed -= 3;
      this.buffSelected = true;
   }
   
   this.speedBuff = function () {   // lets player move faster
      this.speed += 5;
      this.buffSelected = true;
   }
   
   this.draw = function() {
      // draw additional layers
      for (var i = 0; i<this.layers.length; i++) {
         ctxt.beginPath();
         ctxt.arc(this.x,this.y,
                  this.size-i*6,
                  0,Math.PI*2);
         ctxt.fillStyle = this.layers[i]; // fill with layer's colour
         ctxt.fill();
      }
   
      // draw the player's colour
      ctxt.beginPath();
      ctxt.arc(this.x,this.y,
               this.size-this.layers.length*8,
               0,Math.PI*2);
      ctxt.fillStyle = this.colour;
      ctxt.fill();
   }  
   
   this.compareColour = function(c) { //compares input colour with sprite's outer layer
      var n = this.layers.length;
      if (n>1 && c==this.layers[0]) {
         this.layers.splice(0,1);
         this.size-=8;
         this.speed++; //player gets a little faster
         return true;
      } else if (n==1 && c==this.colour) {
         endGame(this.name);
      }
      return false;
   }
}
