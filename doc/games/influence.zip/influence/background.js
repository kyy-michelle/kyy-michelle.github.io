/*
 * background.js
 *
 */
 
 function Background() {
   this.img;
   this.platforms = [];
   this.setBG = function(b){
      if (b == "plain") {
         this.img = document.getElementById("plain");
         this.platforms[0] = [122+150,440+16,301,35]; // midpoint x, midpoint y,width,height
         this.platforms[1] = [400+224,240+16,448,35];
         this.platforms[2] = [850+150,440+16,301,35];
      }
   }
 }
