/*
 * menu.js
 *
 */
 
 function Menu() {
   this.x = 300;
   this.y = 100;
   this.width = 680;
   this.height = 520;
   this.colour = "orange";
   this.open = true; // an open menu pauses gameplay
   this.restart = new Button("Restart",350,560,false);
   this.resume = new Button("Resume",800,560,false);
   this.next = new Button("Next",800,560,true);
   this.mode = "select"; // select menu or main menu - start with select menu
   this.endText = "";
   
   this.mainMenu = function() {
      this.mode = "main";
      this.restart.active = true;
      this.resume.active = true;
      this.next.active = false;
   }
   
   this.selectMenu = function() {
      this.mode = "select";
      this.restart.active = false;
      this.resume.active = false;
      this.next.active = true;
   }
   
   this.display = function() {
      ctxt.fillStyle = this.colour;
      ctxt.fillRect(this.x,this.y,this.width,this.height);
      
      ctxt.fillStyle = "white";
      ctxt.font = "100px sans-serif";
      ctxt.fillText("Influence",this.x+140,this.y+100);
      
      if (this.mode == "main") {
         if (gameEnd) {
            ctxt.font = "30px sans-serif";
            ctxt.fillText(this.endText,this.x+260,this.y+200);
         } else {
            this.drawControls();
         }
      } else if (this.mode == "select") {
         this.drawSelect();
      }
      
      if (this.restart.active) this.restart.draw();
      if (this.resume.active) this.resume.draw();
      if (this.next.active) this.next.draw();
   }
   
   this.drawSelect = function() {
      ctxt.font = "30px sans-serif";
      ctxt.fillText("Select your buff : ",this.x+150,this.y+170);
      this.drawParagraph(["Extra Layer","Shoot Faster","Speed Boost"],
                           this.x+250,this.y+220,70);
                           
      if (!p1.buffSelected) {
         ctxt.fillStyle = "red";
         ctxt.fillRect(this.x+150,this.y+198,30,30);
         ctxt.fillRect(this.x+150,this.y+268,30,30);
         ctxt.fillRect(this.x+150,this.y+338,30,30);
      }
      
      if (!p2.buffSelected) {
         ctxt.fillStyle = "blue";
         ctxt.fillRect(this.x+450,this.y+198,30,30);
         ctxt.fillRect(this.x+450,this.y+268,30,30);
         ctxt.fillRect(this.x+450,this.y+338,30,30);
      }
   }
   
   this.drawControls = function() {
      ctxt.font = "30px sans-serif";
      ctxt.fillText("P1 Controls :",this.x+50,this.y+150);
      this.drawParagraph(["Up - 'W'","Down - 'S'","Left - 'A'","Right - 'D'","Shoot bubble - 'Q'"],
                           this.x+50,this.y+190,35);
      
      ctxt.font = "30px sans-serif";
      ctxt.fillText("P2 Controls :",this.x+400,this.y+150);
      this.drawParagraph(["Up - Up Arrow","Down - Down Arrow","Left - Left Arrow","Right - Right Arrow","Shoot bubble - Enter"],
                           this.x+400,this.y+190,35);
      
      ctxt.fillText("Open Menu - 'Esc'",this.x+50,this.y+400);
   }
   
   this.drawParagraph = function(t,x,y,sp) {// takes in an array of text and spaces them out
      ctxt.font = "24px sans-serif";
      for (var i = 0; i<t.length; i++) {
         ctxt.fillText(t[i],x,y+(i*sp));
      }
   }
 }
 
 function Button(t,x,y,a) { // button size 130x40
   this.active = a; // whether or not this button is active
   this.x = x;
   this.y = y;
   this.text = t;
   this.colour = "rgb(84,62,5)";
   this.draw = function() {
      ctxt.fillStyle = this.colour;
      ctxt.fillRect(x,y,130,40);
      ctxt.lineWidth = 5;
      ctxt.font = "18px sans-serif";
      ctxt.fillStyle = "white";
      ctxt.fillText(this.text,x+30,y+28);
   }
}