/*
 * bullets.js
 *
 */

// sound var //
var loseLayer = new Audio ("piano3.wav"); //sound effect for when the player looses a colour layer
 
function Bullet(x,y,dx,dy,c) {
   this.x = x;
   this.y = y;
   this.dir_x = dx;
   this.dir_y = dy;
   this.colour = c;
   this.size = 10; //radius
   this.speed = SPEED/2	-2;
   
   this.draw = function() {
      ctxt.beginPath();
      ctxt.arc(this.x,this.y,
               this.size,
               0,Math.PI*2);
      ctxt.fillStyle = this.colour;
      ctxt.fill();
   }
   
   this.move = function() { // return true if this bullet is to be removed
      var remove = false;
      if (this.x < this.dir_x) this.x+=this.speed;

      if (this.x > this.dir_x) this.x-=this.speed;

      if (this.y < this.dir_y) this.y+=this.speed;

      if (this.y > this.dir_y) this.y-=this.speed;
	  
	  //remove bullet if it collides with a player/platform or reaches end of path
	  if (platformCollision(this.x,this.y,this.size) ||
	      (this.dir_x-SPEED < this.x 
	  		&& this.x < this.dir_x+SPEED 
	  		&& this.dir_y-SPEED < this.y
			&& this.y < this.dir_y+SPEED)) {
			   remove = true;
			}
			
		if (playerCollision(this.x,this.y,this.size,p1.x,p1.y,p1.size)) {
		   if (p1.compareColour(this.colour) == true) loseLayer.play();
		   remove = true;
		}
		
		if (playerCollision(this.x,this.y,this.size,p2.x,p2.y,p2.size)) {
		   if (p2.compareColour(this.colour) == true) loseLayer.play();
		   remove = true;
		}
	  
	  return remove;
   }  
}

 
function Bullets() {
   this.bullet_array = new Array();
   this.num = 0;
   
   this.draw = function() {
      for (var i = 0; i<this.bullet_array.length; i++) {
         this.bullet_array[i].draw();
      }
   }
   
   this.addBullet = function(x,y,ox,oy,c,r) {
      var bx =  x;
      var by = y;
      
      if (x < ox-80) {
         bx = x+r;
      } else if (x > ox+80) {
         bx = x-r;
      }
      
      if (y < oy-80) {
         by = y+r;
      } else if (y > oy+80) {
         by = y-r;
      }
      
      var b = new Bullet(bx,by,ox,oy,c);
      this.bullet_array.push(b);
      this.num++;
   }
   
   this.moveBullets = function() {
	  for (var i = 0; i<this.bullet_array.length; i++) {
         if (this.bullet_array[i].move()) {
			 this.bullet_array.splice(i,1);
		 }
      } 
   }
}

