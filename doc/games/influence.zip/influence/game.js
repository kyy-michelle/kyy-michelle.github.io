/*
 * game.js
 *
 */

 /**************************************************
 ******************  global vars ******************
 *************************************************/
// display vars //
var MAX_WIDTH = 1280;
var MAX_HEIGHT = 720;
var BORDER = 20;
var FPS = 40;
var frame_count; //used for timing events such as bullet shooting
// gameplay vars //
var GRAVITY = 3;
var SPEED = 25;
var FRICTION = 0.9;
var MAX_JUMP = 6;
var keys; //http://stackoverflow.com/questions/15661796/how-to-handle-multiple-keypresses-with-canvas
var gameEnd = false;
var menu = new Menu();
//environment vars //
var RATE = 8; // rate at which the bullets are fired
var colours = new Array("red","green","blue","yellow","orange","purple");
var buffs = new Array("speed","layer");
var bullets;
var bg; //background
// player vars //
var p1;
var p2;
var p1_wins = 0;
var p2_wins = 0;
var p1_jump = 0;
var p2_jump = 0;
// sound vars //
var p1Shoot = new Audio ("piano1.wav");
var p2Shoot = new Audio ("piano2.wav");
var gameOver = new Audio ("piano_final.wav");
var bgm = new Audio("game_loop.wav");
bgm.loop = true;
bgm.play();
/**************************************************
 ***********  setting up the canvas... ***********
 *************************************************/
var canvas = document.getElementById("game_canvas");
var ctxt = canvas.getContext("2d");
canvas.width = MAX_WIDTH;
canvas.height = MAX_HEIGHT;

window.addEventListener("keydown", function(e) { 
   keys[e.keyCode] = true;
},false);

window.addEventListener("keyup", function(e) { 
   keys[e.keyCode] = false;
},false);

canvas.addEventListener("click", function(e) { // listen for button clicks
   if (menu.open) {
      var rect = canvas.getBoundingClientRect();
      var mX = e.clientX - rect.left;
      var mY = e.clientY - rect.top;
      if ((mX>350 && mX<480) && (mY>560 && mY<600)) {  //restart button
         setup();
         menu.selectMenu();
      } else if ((mX>800 && mX<940) && (mY>560 && mY<600)) { //resume button
         if (menu.mode == "main") {
            menu.open = false;   //resume button
         } else if (p1.buffSelected && p2.buffSelected) {
            menu.mainMenu();  //next button - can only be used when both players have selected buffs
         }
      }
      
      if (menu.mode == "select") {  // player buff buttons
         if (!p1.buffSelected) {
            if ((mX>450 && mX<480) && (mY>298 && mY<328)) p1.layerBuff();
            if ((mX>450 && mX<480) && (mY>368 && mY<398)) p1.shootBuff();
            if ((mX>450 && mX<480) && (mY>438 && mY<468)) p1.speedBuff();
         }
         
         if (!p2.buffSelected) {
            if ((mX>750 && mX<780) && (mY>298 && mY<328)) p2.layerBuff();
            if ((mX>750 && mX<780) && (mY>368 && mY<398)) p2.shootBuff();
            if ((mX>750 && mX<780) && (mY>438 && mY<468)) p2.speedBuff();
         }
      }
   }
},false);

/**************************************************
 ***********  setting up the game **************
 *************************************************/
keys = new Array(); //keyboard input
bg = new Background();
bg.setBG("plain");
 
function setup() {
   frame_count = 0;
   gameEnd = false;
   p1 = new Sprite(70,MAX_HEIGHT-130,"red","Player 1");
   p2 = new Sprite(MAX_WIDTH-70,MAX_HEIGHT-130,"blue","Player 2");
   p1.setup();
   p2.setup();
   bullets = new Bullets();
   menu.colour = "orange";
}

setup();
menu.open = true; // open menu before game starts

/**************************************************
 *********************  game loop ***************
 *************************************************/
setInterval(function() { 
   if (!menu.open) {
      handleKeypress();
      if (!gameEnd) update(); // only update gamestate when it's running
   }
   draw();
}, 1000/FPS);

function update() {
   movePlayers();
   if (bullets.num > 0) bullets.moveBullets();
   frame_count++;
}

function draw() {
   ctxt.shadowColor = "rgba(0,0,0,0)"; // turn off shadows
   ctxt.drawImage(bg.img,0,0,MAX_WIDTH,MAX_HEIGHT);
   p1.draw();
   p2.draw();
   bullets.draw();
   
   ctxt.fillStyle = "white";
   ctxt.font = "24px sans-serif";
   ctxt.shadowOffsetX = 2;
   ctxt.shadowOffsetY = 2;
   ctxt.shadowBlur = 5;
   
   ctxt.shadowColor = "red";  //draw p1 score
   ctxt.fillText("P1 Wins : " + p1_wins,50,MAX_HEIGHT-50);
   ctxt.shadowColor = "blue";  //draw p2 score
   ctxt.fillText("P2 Wins : " + p2_wins,MAX_WIDTH-190,MAX_HEIGHT-50);
   
   if (menu.open) {
      ctxt.shadowColor = "rgb(84,62,5)";
      menu.display();
   }
}

/**************************************************
 *********************  movement ******************
 *************************************************/
function movePlayers() { //http://www.newgrounds.com/portal/view/448915
   if (p1.y < (MAX_HEIGHT-100) && !platformCollision(p1.x,p1.y,p1.size)) { //move p1 in y direction
      p1.vel_y += GRAVITY;
      p1.onPlatform = false;
   } else {
      if (p1.vel_y > 0) p1.vel_y = 0;
      p1_jump = 0;
      p1.onPlatform = true;
   }
   
   p1.vel_y *= FRICTION;
   p1.y += p1.vel_y;

   if (p1.y < 0) p1.y = 0;
   
   p1.vel_x *= FRICTION;   // move p1 in x direction
   p1.x += p1.vel_x;
   if (p1.x < 0) {
      p1.x = 0;
   } else if (p1.x > MAX_WIDTH) {
      p1.x = MAX_WIDTH;
   }
   
   
   if (p2.y < (MAX_HEIGHT-100) && !platformCollision(p2.x,p2.y,p2.size)) { //move p2 in y direction
      p2.vel_y += GRAVITY;
      p2.onPlatform = false;
   } else {
      if (p2.vel_y > 0) p2.vel_y = 0;
      p2_jump = 0;
      p2.onPlatform = true;
   }
   
   p2.vel_y *= FRICTION;
   p2.y += p2.vel_y;
   if (p2.y < 0) p2.y = 0;
   
   p2.vel_x *= FRICTION;   // move p2 in x direction
   p2.x += p2.vel_x;
   if (p2.x < 0) {
      p2.x = 0;
   } else if (p2.x > MAX_WIDTH) {
      p2.x = MAX_WIDTH;
   }
}

function handleKeypress() { //http://info.sonicretro.org/SPG:Jumping http://jsfiddle.net/loktar/dMYvG/
   var p1_vel = p1.speed/10;
   var p2_vel = p2.speed/10;
   
   if (keys[27]) { // ESCAPE
      menu.open = true;
   }
   
   // player 1 //
   if (keys[81] && frame_count%p1.shoot_speed == 0) { // Q - p1 shoots
      shoot(p1.x,p1.y,p2.x,p2.y,p1.size);
      p1Shoot.play();  
   }
   
   if (keys[87]) { // W
      if (p1.vel_y > -p1.speed && p1_jump<MAX_JUMP) {
         p1.vel_y -= p1_vel*GRAVITY;
         p1_jump++;
      }
   } else if (keys[83]) { // S
      if (p1.vel_y < p1.speed) p1.vel_y += p1_vel;         
   }
   
   if (keys[65]) { // A
      if (p1.vel_x > -p1.speed) p1.vel_x -= p1_vel;
   } else if (keys[68]) { // D
      if (p1.vel_x < p1.speed) p1.vel_x += p1_vel;
   }
   
   
   
   // player 2 //
   if (keys[13] && frame_count%p2.shoot_speed == 0) { // ENTER - p2 shoots
      shoot(p2.x,p2.y,p1.x,p1.y,p2.size);
      p2Shoot.play(); 
   }
   
   if (keys[38]) { // UP
      if (p2.vel_y > -p2.speed && p2_jump<MAX_JUMP) {
         p2.vel_y -= p1_vel*GRAVITY;
         p2_jump++;
      }
   } else if (keys[40]) { // DOWN
      if (p2.vel_y < p2.speed) p2.vel_y += p2_vel; 
   }
   
   if (keys[37]) { // LEFT
      if (p2.vel_x > -p2.speed) p2.vel_x -= p2_vel;
   } else if (keys[39]) { // RIGHT
      if (p2.vel_x < p2.speed) p2.vel_x += p2_vel;
   }
}

/**************************************************
 ****************  collision detection ************
 *************************************************/
function platformCollision(px,py,size) { //http://stackoverflow.com/questions/401847/circle-rectangle-collision-detection-intersection
   var collide = false;
   var skip;
   for (var i = 0; i<bg.platforms.length; i++) {
      skip = false;
      var pfm = bg.platforms[i];
      var cx = Math.abs(px - pfm[0]);
      var cy = Math.abs(py - pfm[1]);
      var cr = size;
      if (cx > (pfm[2]/2 + cr)) {skip = true;}
      if (cy > (pfm[3]/2 + cr)) {skip = true;}
      
      if (!skip) {
         if (cx <= (pfm[2]/2)) {return true;}
         if (cy <= (pfm[3]/2)) {return true;}
         
         var cd = (cx - pfm[2]/2)*(cx - pfm[2]/2) 
                     + (cy - pfm[3]/2)*(cy - pfm[3]/2);
         if (cd <= cr*cr) {return true;}
      }
   }
   return collide;
}

function playerCollision(x1,y1,s1,x2,y2,s2) { //check if 2 circular objects collide
   var cx = x1 - x2;
   var cy = y1 - y2;
   var cr = s1 + s2;
   if ((cx*cx) + (cy*cy) <= cr*cr) { // collision detected
      return true;
   }
   return false;
}

/**************************************************
 *********************  game logic ***************
 *************************************************/
function shoot(x,y,ox,oy,r) { // fire a random coloured bullet towards enemy x,y->ox,oy
   bullets.addBullet(x,y,ox,oy,randomColour(),r+10); // r is the player size offset
}

function randomColour() { //returns a random colour from the colours array
   return colours[Math.floor(Math.random()*colours.length)];
} 

function endGame(p) { // pass in name of losing player
   if (p == "Player 1") { // p2 wins
      p2_wins++;
      menu.colour = p2.colour;
      menu.endText = "Player 2 Wins!";
   } else if (p == "Player 2") { //p1 wins
      p1_wins++;
      menu.colour = p1.colour;
      menu.endText = "Player 1 Wins!";
   }
   gameOver.play();
   gameEnd = true;
   menu.open = true;
} 
