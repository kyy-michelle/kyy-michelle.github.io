define(function(require) {

  var Event = require("./event.js");

  return function(dom, rootDom) {

    var Mouse = {};

    var pressTime = 0;

    var evt = new Event();
    Mouse.on = evt.on;
    Mouse.off = evt.off;

    dom.addEventListener("mousemove", function(e) {
      Mouse.x = e.pageX - $(dom).offset().left;
      Mouse.y = e.pageY - $(dom).offset().top;
    });

    dom.addEventListener("mousedown", function(e) {
      Mouse.down = true;

      pressTime = new Date().getTime();

      evt.trigger("down", {
        mouseX: Mouse.x,
        mouseY: Mouse.y
      });
    });

    rootDom.addEventListener("mouseup", function(e) {
      Mouse.down = false;

      evt.trigger("up", {
        mouseX: Mouse.x,
        mouseY: Mouse.y
      });

      if (new Date().getTime() - pressTime < 200) {
        evt.trigger("click", {
          mouseX: Mouse.x,
          mouseY: Mouse.y
        });
      }
    });

    return Mouse;

  };

});
