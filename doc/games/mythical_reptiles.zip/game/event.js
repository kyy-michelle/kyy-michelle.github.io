define(function(require) {

  function Event() {
    var handlers = {};

    this.on = function(name, handler) {
      if (!handlers[name])
        handlers[name] = [];

      handlers[name].push(handler);
    };

    this.off = function(name, handler) {
      if (!handlers[name])
        return;

      var i = handlers[name].indexOf(handler);
      if (i < 0)
        return;

      handlers[name].splice(i, 1);
    };

    this.trigger = function(name, e) {
      if (!handlers[name])
        return;

      handlers[name].forEach(function(handler) {
        handler.call(this, e);
      });
    };
  };

  return Event;

});
