define(function(require) {

  var Player  = require("./player.js"),
      Monster = require("./monster.js"),
      Item    = require("./item.js");

  function Battle(game, gameMonster) {
    this.game = game;

    this.cols = 12;
    this.rows = 6;

    this.tileWidth = 50;
    this.tileHeight = 50;

    var player = new Player(null, 1, 4);
    player.stats = this.game.player.stats;
    var monster = new Monster(null, 10, 1);
    monster.stats = gameMonster.stats;
    var currentSpell = null;

    var turn = "player";

    player.updateStatsUI();
    gameLog("You encounter a level " + monster.stats.level
        + " " + monster.stats.name + "!");

    var onClick = function(e) {
      if (turn != "player") {
        return;
      }

      var p = {
        col: Math.floor(e.mouseX / this.tileWidth),
        row: Math.floor(e.mouseY / this.tileHeight)
      };

      if (manDistance(player, p) > player.stats.walkRange) {
        return;
      }

      turn = null;
      doWalk(player, p, function() {
        turn = "monster";
        monsterTurn();
      });
    }.bind(this);
    Mouse.on("click", onClick);

    var attackHover = false,
        spellHover = false;

    $("#action-1").on("mouseover", function() {
      attackHover = true;
    }).on("mouseout", function() {
      attackHover = false;
    });

    $("#action-1").text("Attack").on("click", function(e) {
      e.preventDefault();

      if (turn != "player") {
        return;
      }

      if (manDistance(player, monster) > player.stats.attackRange) {
        gameLog("You are not near enough to attack!");
        return;
      }

      turn = null;
      doAttack(player, monster, function() {
        turn = "monster";
        monsterTurn();
      });
    });

    if (player.stats.spellType) {
      $("#action-2").on("mouseover", function() {
        spellHover = true;
      }).on("mouseout", function() {
        spellHover = false;
      });

      $("#action-2").text(player.stats.spellName).on("click", function(e) {
        e.preventDefault();

        if (turn != "player") {
          return;
        }

        if (pyDistance(player, monster) > player.stats.spellRange) {
          gameLog("You are not near enough to cast this spell!");
          return;
        }

        if (player.stats.mana < player.stats.spellMana) {
          gameLog("You require more mana!");
          return;
        }

        turn = null;
        doSpell(player, monster, function() {
          turn = "monster";
          monsterTurn();
        });
      });
    }

    $("#action-3").text("Flee").on("click", function(e) {
      e.preventDefault();

      if (turn != "player") {
        return;
      }

      // todo: take away player's health?
      if (player.stats.level < monster.stats.level) {
        gameLog("You cannot escape!");
      } else {
        gameLog("You escape to safety.");
        this.game.exitBattleMode(gameMonster);
      }
    }.bind(this));

    var manDistance = function(a, b) {
      return Math.abs(b.row - a.row) + Math.abs(b.col - a.col);
    };
    var pyDistance = function(a, b) {
      var dy = b.row - a.row;
      var dx = b.col - a.col;
      return Math.sqrt(dy*dy + dx*dx);
    };

    var doWalk = function(obj, p, done) {
      var stepAlong = function(t, next) {
        if (obj[t] == p[t]) {
          next();
        } else {
          var tween = {
            time: 0.3,
            onComplete: function() {
              stepAlong(t, next);
            }
          };
          tween[t] = obj[t] < p[t] ? obj[t] + 1 : obj[t] - 1;
          Tweener.addTween(obj, tween);
        }
      };

      var dx = Math.abs(p.col - obj.col);
      var dy = Math.abs(p.row - obj.row);

      if (dx < dy) {
        stepAlong("col", function() {
          stepAlong("row", done);
        });
      } else {
        stepAlong("row", function() {
          stepAlong("col", done);
        });
      }
    }.bind(this);

    var doAttack = function(attacker, victim, done) {
      var oldCol = attacker.col;
      var oldRow = attacker.row;

      Tweener.addTween(attacker, {
        col: victim.col,
        row: victim.row,
        time: 0.1,
        transition: "easeNone",
        onComplete: function() {
          processAttack(attacker, victim);
          Tweener.addTween(attacker, {
            col: oldCol,
            row: oldRow,
            time: 0.15,
            transition: "easeOutExpo",
            onComplete: done
          });
        }
      });
    }.bind(this);

    var doSpell = function(attacker, victim, done) {
      currentSpell = { type: attacker.stats.spellType, col: attacker.col, row: attacker.row };
      Tweener.addTween(currentSpell, {
        col: victim.col,
        row: victim.row,
        time: 0.15,
        transition: "linear",
        onComplete: function() {
          processSpell(attacker, victim);
          currentSpell = null;
          done();
        }
      });
    }.bind(this);

    var processAttack = function(attacker, victim) {
      var min = attacker.stats.attackMinDamage,
          max = attacker.stats.attackMaxDamage,
          r = Math.random(),
          damage = Math.round(r * (max - min) + min);

      var logMsg;

      if (attacker == player) {
        logMsg = "You attack the " + monster.stats.name + ", causing " +
          damage + " damage";
      } else {
        logMsg = "The " + monster.stats.name + " attacks you, causing "
          + damage + " damage";
      }

      if (r > 0.9) {
        logMsg += ": a direct hit!";
      } else if (r < 0.1) {
        logMsg += ": a poor hit.";
      } else {
        logMsg += ".";
      }

      victim.stats.health -= damage;
      if (victim.stats.health <= 0) {
        victim.stats.health = 0;

        gameLog(logMsg);

        processDeath(victim);
      } else {
        if (victim == monster) {
          logMsg += " " + monster.stats.health + " HP remaining.";
        }

        gameLog(logMsg);
      }

      player.updateStatsUI();
    }.bind(this);

    var processSpell = function(attacker, victim) {
      var min = attacker.stats.spellMinDamage,
          max = attacker.stats.spellMaxDamage,
          r = Math.random(),
          damage = Math.round(r * (max - min) + min);

      var logMsg;

      if (attacker == player) {
        logMsg = "You cast " + player.stats.spellName + " at the " + monster.stats.name + ", causing " +
          damage + " damage";
      } else {
        logMsg = "The " + monster.stats.name + " casts " + monster.stats.spellName + " at you, causing "
          + damage + " damage";
      }

      if (r > 0.9) {
        logMsg += ": a direct hit!";
      } else if (r < 0.1) {
        logMsg += ": a poor hit.";
      } else {
        logMsg += ".";
      }

      attacker.stats.mana -= attacker.stats.spellMana;
      if (attacker.stats.mana <= 0) {
        attacker.stats.mana = 0;
      }

      victim.stats.health -= damage;
      if (victim.stats.health <= 0) {
        victim.stats.health = 0;

        gameLog(logMsg);

        processDeath(victim);
      } else {
        if (victim == monster) {
          logMsg += " " + monster.stats.health + " HP remaining.";
        }

        gameLog(logMsg);
      }

      player.updateStatsUI();
    }.bind(this);

    var processDeath = function(victim) {
      if (victim == monster) {
        player.stats.kills += 1;
        player.stats.totalKills += 1

        gameLog("You slay the " + monster.stats.name + ".");

        player.checkLevelUp();

        if (Math.random() < 0.6 && manDistance(gameMonster, this.game.player) < 10) {
          var item = new Item(this.game, Math.round(gameMonster.col), Math.round(gameMonster.row));
          player.stats.itemsFound += 1;
          this.game.objects.unshift(item);
        }

        this.game.exitBattleMode(gameMonster, player.stats);

      } else {
        // todo
        gameLog("You have died.");
        this.game.exitBattleMode(gameMonster);
      }
    }.bind(this);

    var monsterTurn = function() {
      var r = Math.random();

      if (r < 0.5 && monster.stats.spellType
          && monster.stats.mana >= monster.stats.spellMana
          && pyDistance(monster, player) <= monster.stats.spellRange) {
        // spell
        turn = null;
        doSpell(monster, player, function() {
          turn = "player";
        });

        return;
      }

      if (manDistance(monster, player) <= monster.stats.attackRange) {
        // attack
        turn = null;
        doAttack(monster, player, function() {
          turn = "player";
        });

        return;
      }

      // move
      // pick random point that is closer to player
      var oldDistance = manDistance(monster, player);
      var p, d;
      do {
        p = { row: rand(0, this.rows - 1), col: rand(0, this.cols - 1) };
        d = manDistance(player, p);
      } while (d >= oldDistance);

      // walk there
      turn = null;
      doWalk(monster, p, function() {
        turn = "player";
      });
    }.bind(this);

    var rand = function(from, to) {
      return Math.round(Math.random() * (to - from) + from);
    };

    // drawing:

    this.draw = function(ctx) {
      // draw grass tile background
      for (var c = 0; c < this.cols; ++c) {
        for (var r = 0; r < this.rows; ++r) {
          var grass = document.getElementById("terrain-grass");
          ctx.drawImage(grass,
            c * this.tileWidth, r * this.tileHeight,
            this.tileWidth, this.tileHeight);

          // if player's turn, draw range feedback
          if (turn == "player") {
            if (attackHover) {
              if (manDistance(player, {col: c, row: r}) <= player.stats.attackRange) {
                ctx.fillStyle = "rgba(0, 0, 255, 0.2)";
                ctx.fillRect(c * this.tileWidth, r * this.tileHeight,
                    this.tileWidth, this.tileHeight);
              }
            } else if (spellHover) {
              if (pyDistance(player, {col: c, row: r}) <= player.stats.spellRange) {
                ctx.fillStyle = "rgba(0, 0, 255, 0.2)";
                ctx.fillRect(c * this.tileWidth, r * this.tileHeight,
                    this.tileWidth, this.tileHeight);
              }
            } else {
              if (manDistance(player, {col: c, row: r}) <= player.stats.walkRange) {
                ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
                ctx.fillRect(c * this.tileWidth, r * this.tileHeight,
                    this.tileWidth, this.tileHeight);
              }
            }
          }

          // draw grid lines
          ctx.strokeStyle = "rgba(0, 0, 0, 0.2)";
          ctx.lineWidth = 1;
          ctx.strokeRect(c * this.tileWidth, r * this.tileHeight,
              this.tileWidth, this.tileHeight);

          // draw cursor
          if (turn == "player") {
            var mouseCol = Math.floor(Mouse.x / this.tileWidth),
                mouseRow = Math.floor(Mouse.y / this.tileHeight);
            if (manDistance(player, {col: mouseCol, row: mouseRow}) <= player.stats.walkRange) {
              ctx.strokeStyle = "red";
              ctx.lineWidth = 2;
              ctx.strokeRect(mouseCol * this.tileWidth, mouseRow * this.tileHeight,
                  this.tileWidth, this.tileHeight);
            }
          }
        }
      }

      // draw player
      drawObject(ctx, player);

      // draw monster
      drawObject(ctx, monster);

      // draw spell
      if (currentSpell) {
        var spell = document.getElementById("spell-" + currentSpell.type);
        ctx.drawImage(spell,
            currentSpell.col * this.tileWidth + this.tileWidth / 2 - 10,
            currentSpell.row * this.tileHeight + this.tileHeight / 2 - 10);
      }
    };

    var drawObject = function(ctx, obj) {
      ctx.save();
      ctx.translate(obj.col * this.tileWidth + this.tileWidth / 2,
          obj.row *  this.tileHeight + this.tileHeight / 2);
      obj.draw(ctx);
      ctx.restore();
    }.bind(this);

    this.dispose = function() {
      Mouse.off("click", onClick);
      $("#action-1").off("click").off("mouseover").off("mouseout");
      $("#action-2").off("click").off("mouseover").off("mouseout");
      $("#action-3").off("click");

      $("#action-1, #action-2, #action-3").text("-");
    };
  }

  return Battle;

});
