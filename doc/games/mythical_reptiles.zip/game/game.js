define(function(require) {

  var Terrain   = require("./terrain.js"),
      Player    = require("./player.js"),
      Event     = require("./event.js"),
      Monster   = require("./monster.js"),
      Battle    = require("./battle.js"),
      Container = require("./container.js"),
      Item      = require("./item.js");

  function Game(canvas) {

    var running = false,
        interval = null;

    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");

    this.tiles = [];
    this.objects = [];

    this.rows = 100;
    this.cols = 100;
    this.tileWidth = 50;
    this.tileHeight = 50;
    this.cameraRow = 20;
    this.cameraCol = 20;

    this.fps = 2.5;

    this.terrain = new Terrain(this);

    var evt = new Event();
    this.on = evt.on;
    this.off = evt.off;

    var init = function() {
      initTiles();
      this.terrain.generate();
      initObjects();
    }.bind(this);

    var initTiles = function() {
      var tiles = [];

      for (var x = 0; x < this.cols; ++x) {
        tiles[x] = [];
        for (var y = 0; y < this.rows; ++y) {
          tiles[x][y] = {};
        }
      }

      this.tiles = tiles;
    }.bind(this);

    var initObjects = function() {
      // create player
      var pos = this.randomPosition();
      this.player = new Player(this, pos.col, pos.row);
      window.player = this.player;
      this.objects.push(this.player);
      this.player.updateStatsUI();

      // create some monsters
      for (var i = 0; i < 70; ++i) {
        spawnMonster();
      }

      // some containers
      for (var i = 0; i < 100; ++i) {
        var pos = this.randomPosition();
        this.objects.unshift(new Container(this, pos.col, pos.row));
      }
    }.bind(this);

    var spawnMonster = function() {
      var pos = this.randomMonsterPosition();
      var monster = new Monster(this, pos.col, pos.row);
      monster.randomiseStats(this.player.stats.level);
      this.objects.push(monster);
    }.bind(this);

    this.start = function() {
      init();

      gameLog("Greetings!");

      running = true;
      tick();
      interval = setInterval(tick, 1000 / this.fps);
      draw();
    };

    this.pause = function() {
      running = false;
      clearInterval(interval);
    };
    this.resume = function() {
      running = true;
      tick();
      if (interval) clearInterval(interval);
      interval = setInterval(tick, 1000 / this.fps);
    };

    this.enterBattleMode = function(monster) {
      if (!this.battle && this.player.stats.health > 0) {
        this.pause();
        this.battle = new Battle(this, monster);
      }
    };

    this.exitBattleMode = function(monster, newPlayerStats) {
      // remove that monster
      var i = this.objects.indexOf(monster);
      if (i >= 0) {
        this.objects.splice(i, 1);
      }

      // spawn a new one
      spawnMonster();

      this.battle.dispose();
      this.battle = null;

      this.player.reset();
      if (newPlayerStats) {
        this.player.stats = newPlayerStats;
      }

      this.resume();
    };

    var tick = function() {
      this.objects.forEach(function(object) {
        object.tick();
      });
    }.bind(this);

    var requestAnimationFrame =
      window.requestAnimationFrame
      || window.webkitRequestAnimationFrame
      || window.mozRequestAnimationFrame
      || window.oRequestAnimationFrame
      || window.msRequestAnimationFrame;

    this.randomPosition = function() {
      var col, row;
      do {
        col = Math.floor(Math.random() * 100);
        row = Math.floor(Math.random() * 100);
      } while (!this.canMoveTo(col, row));
      return { col: col, row: row };
    };

    this.randomMonsterPosition = function() {
      var p;
      do {
        p = this.randomPosition();
      } while (this.manDistance(this.player.col, this.player.row, p.col, p.row) < 10);
      return p;
    };

    this.canMoveTo = function(col, row) {
      col = Math.round(col);
      row = Math.round(row);
      return col >= 0
          && row >= 0
          && col < this.cols
          && row < this.rows
          && this.tiles[col][row].terrain == "grass";
    };

    this.manDistance = function(c1, r1, c2, r2) {
      return Math.abs(c2 - c1) + Math.abs(r2 - r1);
    };

    this.cameraBounds = function() {
      var drawCols = Math.ceil((this.canvas.width / 2) / this.tileWidth);
      var drawRows = Math.ceil((this.canvas.height / 2) / this.tileHeight);

      return {
        left: Math.max(0, Math.round(this.cameraCol - drawCols)),
        right: Math.min(this.cols - 1, Math.round(this.cameraCol + drawCols)),
        top: Math.max(0, Math.round(this.cameraRow - drawRows)),
        bottom: Math.min(this.rows - 1, Math.round(this.cameraRow + drawRows))
      };
    };

    this.colToX = function(col) {
      return this.canvas.width / 2 - this.tileWidth / 2
        - this.cameraCol * this.tileWidth
        + col * this.tileWidth;
    };
    this.rowToY = function(row) {
      return this.canvas.height / 2 - this.tileHeight / 2
        - this.cameraRow * this.tileHeight
        + row * this.tileHeight;
    };

    this.xToCol = function(x) {
      var col = (x - this.canvas.width / 2 - this.tileWidth / 2
          + this.cameraCol * this.tileWidth) / this.tileWidth;
      return Math.floor(col) + 1;
    };
    this.yToRow = function(y) {
      var row = (y - this.canvas.height / 2 - this.tileHeight / 2
          + this.cameraRow * this.tileHeight) / this.tileHeight;
      return Math.floor(row) + 1;
    };

    var draw = function() {
      if (running || this.battle) {
        requestAnimationFrame(draw);
      }

      var ctx = this.ctx;

      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

      if (this.battle) {
        this.battle.draw(ctx);
        return;
      }

      this.cameraRow = this.player.row;
      this.cameraCol = this.player.col;

      var bounds = this.cameraBounds();
      var offsetX = this.colToX(0);
      var offsetY = this.rowToY(0);

      for (var c = bounds.left; c <= bounds.right; ++c) {
        for (var r = bounds.top; r <= bounds.bottom; ++r) {
          var x = c * this.tileWidth + offsetX;
          var y = r * this.tileHeight + offsetY;

          ctx.save();
          ctx.translate(x, y);

          // draw terrain
          this.terrain.drawTile(this.tiles[c][r].terrain);

          // draw some lines, hell yeah
          ctx.strokeStyle = "rgba(0, 0, 0, 0.2)";
          ctx.lineWidth = 1;
          ctx.strokeRect(0, 0, this.tileWidth, this.tileHeight);

          ctx.restore();
        }
      }

      // cursor
      var cursorCol = this.xToCol(Mouse.x);
      var cursorRow = this.yToRow(Mouse.y);
      if (cursorCol >= 0 && cursorCol < this.cols
          && cursorRow >= 0 && cursorRow < this.rows) {
        ctx.strokeStyle = "red";
        ctx.lineWidth = 2;
        ctx.strokeRect(this.colToX(cursorCol), this.rowToY(cursorRow),
            this.tileWidth, this.tileHeight);
      }

      for (var i in this.objects) {
        var object = this.objects[i];

        ctx.save();

        var x = this.colToX(object.col) + this.tileWidth / 2;
        var y = this.rowToY(object.row) + this.tileHeight / 2;
        ctx.translate(x, y);

        object.draw(ctx);

        ctx.restore();
      }
      
      if (this.player.stats.health <= 0) { //show score box when player dies
        var img = document.getElementById("score-box");
        ctx.drawImage(img,100,15);
        
        var box = document.getElementById("score");
        box.style.display = "inline";
        box.innerHTML = "<b>You have died!</b><br>" +
                  "<br><b>Level:</b> " + this.player.stats.level + " x 100" +
                  "<br><b>Items Found:</b> " + this.player.stats.itemsFound + " x 20" +
                  "<br><b>Monsters Killed:</b> " + this.player.stats.totalKills+ " x 50" +
                  "<br><br><b>Final Score</b> = " + (this.player.stats.level*100 + 
                                                      this.player.stats.itemsFound*20 +
                                                      this.player.stats.totalKills*50);
      }
      
    }.bind(this);

    // tile select event
    Mouse.on("click", function(e) {
      if (running && this.player.stats.health > 0) { //disable tile clicks when player dies
        var col = this.xToCol(e.mouseX);
        var row = this.yToRow(e.mouseY);
        evt.trigger("tileSelect", {
          row: row,
          col: col
        });
      }
    }.bind(this));

  };

  return Game;

});
