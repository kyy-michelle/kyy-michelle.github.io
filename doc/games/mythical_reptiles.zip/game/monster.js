define(function(require) {

  function Monster(game, col, row) {
    this.game = game;

    // populated for reals in randomiseStats
    this.stats = {
      level: 1,
      type: "blob",
      name: "Blob",

      health: 10,
      maxHealth: 10,
      mana: 0,
      maxMana: 0,

      walkRange: 3,

      attackRange: 2,
      attackMinDamage: 5,
      attackMaxDamage: 6,

      spellRange: 0,
      spellName: "",
      spellType: null,
      spellMinDamage: 0,
      spellMaxDamage: 0,
      spellMana: 0,

      encounterRange: 3
    };

    this.row = row;
    this.col = col;

    var facingX = "left",
        facingY = "front";

    this.tick = function() {
      if (Math.random() < 0.3) {
        var dir = Math.floor(Math.random() * 4);
        if (dir == 0) {
          if (this.game.canMoveTo(this.col, this.row + 1)) {
            Tweener.addTween(this, { row: this.row + 1, time: 0.4 });
            facingY = "front";
          }

        } else if (dir == 1) {
          if (this.game.canMoveTo(this.col, this.row - 1)) {
            Tweener.addTween(this, { row: this.row - 1, time: 0.4 });
            facingY = "back";
          }

        } else if (dir == 2) {
          if (this.game.canMoveTo(this.col + 1, this.row)) {
            Tweener.addTween(this, { col: this.col + 1, time: 0.4 });
            facingX = "right";
          }

        } else if (dir == 3) {
          if (this.game.canMoveTo(this.col - 1, this.row)) {
            Tweener.addTween(this, { col: this.col - 1, time: 0.4 });
            facingX = "left";
          }
        }
      }

      var player = this.game.player;
      var dist = this.game.manDistance(this.col, this.row, player.col, player.row);
      if (dist <= this.stats.encounterRange) {
        this.randomiseStats(player.stats.level, true);
        this.game.enterBattleMode(this);
      }
    };

    this.draw = function(ctx) {
      if (this.stats.type == "dragon") {
        var img = document.getElementById("dragon-" + facingX);
        ctx.drawImage(img, -50, -70);
      } else if (this.stats.type == "blob") {
        var img = document.getElementById("blob-" + facingY);
        ctx.drawImage(img, -25, -25);
      } else if (this.stats.type == "bunny") {
        var img = document.getElementById("bunny-" + facingX);
        ctx.drawImage(img, -25, -25);
      }
    };

    var rand = function(from, to) {
      return Math.round(Math.random() * (from - to) + to);
    };

    var pickType = function() {
      var types = [
        {
          chance: 0.1,
          type: "dragon"
        },
        {
          chance: 0.45,
          type: "blob"
        },
        {
          chance: 0.45,
          type: "bunny"
        }
      ];

      var p = Math.random(),
          accum = 0;
      for (var i in types) {
        var x = types[i];
        if (p < accum + x.chance) {
          return x.type;
        }
        accum += x.chance;
      }
    }.bind(this);

    this.randomiseStats = function(playerLevel, keepType) {
      var level = Math.max(1, playerLevel + rand(-2, 1));
      this.stats.level = level;

      if (!keepType) {
        var type = pickType();
        this.stats.type = type;
      } else {
        var type = this.stats.type
      }

      if (type == "blob") {
        this.stats.name = "Blob";

        this.stats.health = 15 + Math.max(0,(2 * level * level+ rand(-5, 5)));
        this.stats.maxHealth = this.stats.health;

        this.stats.mana = 10;
        this.stats.maxMana = this.stats.mana;
        
        if (this.stats.level > 3) {
            this.stats.walkRange = 3;
        
            this.stats.attackRange = 3;
        } else {
            this.stats.walkRange = 2;
        
            this.stats.attackRange = 2;
        }

        this.stats.attackMinDamage = 1 + Math.max(0,(2 * level + rand(-10, 5)));
        this.stats.attackMaxDamage = 2 + Math.max(0,(2 * level * level + rand(-10, 5)));

        if (this.stats.level > 5) { // No super powered low level blobs
            this.stats.spellRange = 5;
            this.stats.spellName = "Water";
            this.stats.spellType = "fire"; // todo: make water spell
            this.stats.spellMinDamage = 0 + Math.max(0,(1 * level + rand(-2, 2)));
            this.stats.spellMaxDamage = 3 + Math.max(0,(2 * level + rand(-2, 2)));
            this.stats.spellMana = 1;
        }

        this.stats.encounterRange = 2;
      } else if (type == "dragon") {
        this.stats.name = "Dragon";

        this.stats.health = 50 + 5 * level * level+ rand(-level, level); //Made them weaker, can change later
        this.stats.maxHealth = this.stats.health;

        this.stats.mana = 100;
        this.stats.maxMana = this.stats.mana;
        if (this.stats.level > 1) {
            this.stats.walkRange = 4;
        
            this.stats.attackRange = 3;
        } else {
            this.stats.walkRange = 3;
        
            this.stats.attackRange = 3;
        }
        if (this.stats.level >= 5 ) {
          this.stats.attackMinDamage = 2 + Math.max(0,(3 * level + rand(-10, 5)));
          this.stats.attackMaxDamage = 3 + Math.max(0,(4 * level* level + rand(-10, 5)));
        } else {
          this.stats.attackMinDamage = 2 + Math.max(0,(2 * level + rand(-10, 5)));
          this.stats.attackMaxDamage = 3 + Math.max(0,(2 * level* level + rand(-10, 5)));
        }

        if (this.stats.level > 2) {
          if (this.stats.level > 7) {
            this.stats.spellRange = 100; // NO ESCAPE
          } else {
            this.stats.spellRange = 9;
          }
          this.stats.spellName = "Fire";
          this.stats.spellType = "fire";
          if (this.stats.level > 7) {
            this.stats.spellMinDamage = 1 + Math.max(0,(3 * level + rand(-10, 5)));
            this.stats.spellMaxDamage = 3 + Math.max(0,(5 * level*level + rand(-level*level, 0)));
          } else {
            this.stats.spellMinDamage = 1 + Math.max(0,(3 * level + rand(-10, 5)));
            this.stats.spellMaxDamage = 3 + Math.max(0,(5 * level + rand(-10, 5)));
          }
          this.stats.spellMana = 1;
        }

        this.stats.encounterRange = 4;
      }  else if (type == "bunny") {
        this.stats.name = "Bunny";
        
        if (this.stats.level < 10) {
          this.stats.health = 15 + Math.max(0,(2 * level * level+ rand(-5, 5)));
          this.stats.maxHealth = this.stats.health
        } else {
          this.stats.health = 10;
          this.stats.maxHealth = this.stats.health;
        }

        this.stats.mana = 10;
        this.stats.maxMana = this.stats.mana;
        
        if (this.stats.level >= 10) {
          this.stats.walkRange = 5;
          this.stats.attackRange = 8;
        }else if (this.stats.level > 3) {
            this.stats.walkRange = 3;
        
            this.stats.attackRange = 3;
        } else {
            this.stats.walkRange = 2;
        
            this.stats.attackRange = 2;
        }
        if (this.stats.level >= 10) {
          this.stats.attackMinDamage = 1 + Math.max(0,(2 * level + rand(-10, 5)));
          // ARE YOU READY FOR THIS!?!??!?!
          this.stats.attackMaxDamage = 2 + Math.max(0,(2 * level * level *level+ rand(-1000,0)));
        } else{
          this.stats.attackMinDamage = 1 + Math.max(0,(2 * level + rand(-10, 5)));
          this.stats.attackMaxDamage = 2 + Math.max(0,(2 * level  + rand(-10, 5)));
        }

        this.stats.encounterRange = 1;
      }
    };
  }

  return Monster;

});

