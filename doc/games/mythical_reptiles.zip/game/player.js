define(function(require) {

  function Player(game, col, row) {
    this.game = game;

    this.stats = {
      level: 1,
      kills: 0,
      
      totalKills: 0,
      itemsFound: 0,
      
      health: 100,
      maxHealth: 125,
      mana: 50,
      maxMana: 50,

      walkRange: 3,

      attackRange: 2,
      attackMinDamage: 3,
      attackMaxDamage: 6,

      spellRange: 1,
      spellName: "",
      spellType: null,
      spellMinDamage: 0,
      spellMaxDamage: 0,
      spellMana: 0
    };

    this.row = row;
    this.col = col;

    var currentPath = [];

    this.dir = "front";

    if (game) {
      game.on("tileSelect", function(e) {
        if (this.game.canMoveTo(e.col, e.row)) {
          this.row = Math.round(this.row);
          this.col = Math.round(this.col);
          var path = this.pathfind(
            [this.col, this.row].join(","),
            [e.col, e.row].join(",")
          );
          if (path) {
            currentPath = path.map(function(x) {
              var ax = x.split(",");
              return {col: +ax[0], row: +ax[1]};
            });

            removeTweens();
            var p = currentPath.shift();
            this.row = p.row;
            this.col = p.col;
          } else {
            // stuck!
            this.row = e.row;
            this.col = e.col;
          }
        }
      }.bind(this));
    }

    var manDistance = function(from, to) {
      var afrom = from.split(",");
      var ato = to.split(",");
      return this.game.manDistance(+afrom[0], +afrom[1], +ato[0], +ato[1]);
    }.bind(this);

    var neighbors = function(x) {
      var ax = x.split(",");
      var res = [];
      if (this.game.canMoveTo(+ax[0] + 1, +ax[1])) {
        res.push([+ax[0] + 1, +ax[1]].join(","));
      }
      if (this.game.canMoveTo(+ax[0] - 1, +ax[1])) {
        res.push([+ax[0] - 1, +ax[1]].join(","));
      }
      if (this.game.canMoveTo(+ax[0], +ax[1] + 1)) {
        res.push([+ax[0], +ax[1] + 1].join(","));
      }
      if (this.game.canMoveTo(+ax[0], +ax[1] - 1)) {
        res.push([+ax[0], +ax[1] - 1].join(","));
      }
      return res;
    }.bind(this);

    // from http://en.wikipedia.org/wiki/A*_search_algorithm#Pseudocode
    this.pathfind = function(start, goal) {
      var g_score = {};
      var f_score = {};

      var closedset = [];
      var openset = [start];
      var came_from = {};

      g_score[start] = 0;
      f_score[start] = g_score[start] + manDistance(start, goal);

      var reconstruct_path = function(current_node) {
        if (current_node in came_from) {
          var p = reconstruct_path(came_from[current_node]);
          return p.concat(current_node);
        } else {
          return [current_node];
        }
      };

      while (openset.length > 0) {
        var lowest = Infinity;
        var current, currentI;
        for (var i = 0; i < openset.length; ++i) {
          if (f_score[openset[i]] < lowest) {
            current = openset[i];
            currentI = i;
            lowest = f_score[current];
          }
        }

        if (current == goal) {
          return reconstruct_path(goal);
        }

        openset.splice(currentI, 1);
        closedset.push(current);

        neighbors(current).forEach(function(neighbor) {
          var tentative_g_score = g_score[current] + 1;
          var tentative_f_score = tentative_g_score + manDistance(neighbor, goal);

          if (closedset.indexOf(neighbor) >= 0 && tentative_f_score >= f_score[neighbor]) {
            return;
          }

          if (openset.indexOf(neighbor) < 0 || tentative_f_score < f_score[neighbor]) {
            came_from[neighbor] = current;
            g_score[neighbor] = tentative_g_score;
            f_score[neighbor] = tentative_f_score;
            if (openset.indexOf(neighbor) < 0) {
              openset.push(neighbor);
            }
          }
        }.bind(this));
      }

      return null;
    };

    var removeTweens = function() {
      for (var i = 0; i < Tweener.twns.length; ++i) {
        if (Tweener.twns[i].obj == this) {
          Tweener.twns.splice(i--, 1);
        }
      }
    }.bind(this);

    this.tick = function() {
      removeTweens();

      if (currentPath.length > 0) {
        var p = currentPath.shift();
        Tweener.addTween(this, { row: p.row, col: p.col, time: 0.3 });
        if (p.row < this.row) {
          this.dir = "back";
        } else if (p.row > this.row) {
          this.dir = "front";
        } else if (p.col < this.col) {
          this.dir = "left";
        } else if (p.col > this.col) {
          this.dir = "right";
        }
      }
    };

    this.draw = function(ctx) {
      var img = document.getElementById("char-" + this.dir);
      ctx.drawImage(img, -25, -25);
    };

    this.reset = function() {
      this.row = Math.floor(this.row);
      this.col = Math.floor(this.col);
      currentPath = [];
    }.bind(this);

    this.updateStatsUI = function() {
      $("#level").text("Lvl " + this.stats.level);
      $("#health").text(this.stats.health + " HP");
      $("#mana").text(this.stats.mana + " MP");
    };

    this.checkLevelUp = function() {
      if (this.stats.kills >= this.stats.level) {
        this.stats.kills = 0;

        this.stats.level += 1;

        this.stats.health += 10;
        this.stats.maxHealth += 10;

        this.stats.mana += 5;
        this.stats.maxMana += 5;

        // up every 5
        if (this.stats.level % 5 == 0) {
          this.stats.walkRange += 1;
          this.stats.attackRange += 1;
        }

        // up every 2
        if (this.stats.attackMinDamage % 2 == 0) {
          this.stats.attackMinDamage += 1;
        }

        this.stats.attackMaxDamage += 1;

        gameLog("You have advanced to level " + this.stats.level + "!");
        //Free replenish when you level up
        this.stats.health=this.stats.maxHealth;
        this.stats.mana=this.stats.maxMana;
        gameLog("Max HP: " + this.stats.maxHealth);
        gameLog("Max MP: " + this.stats.maxMana);
        gameLog("Range: " + this.stats.walkRange + "/" + this.stats.attackRange);
        gameLog("Damage: " + this.stats.attackMinDamage + "-" + this.stats.attackMaxDamage);
        gameLog("Find a spell book to learn a higher level spell.");
      };
    };

    this.giveSpell = function(spellType) {
      if (spellType == "fire") {
        this.stats.spellType = "fire";
        this.stats.spellName = "Fire";

        var level = this.stats.level;

        this.stats.spellMinDamage = 5 + level * 3;
        this.stats.spellMaxDamage = 5 + level * 4;
        this.stats.spellMana = 5 + 2 * level;
        this.stats.spellRange = level > 10 ? 7 : 5;

        gameLog("You have learnt level " + level + " " + this.stats.spellName + "!");
        gameLog("Range: " + this.stats.spellRange);
        gameLog("Damage: " + this.stats.spellMinDamage + "-" + this.stats.spellMaxDamage);
        
      } else if (spellType == "water") {
        this.stats.spellType = "water";
        this.stats.spellName = "Water";

        var level = this.stats.level;

        this.stats.spellMinDamage = 2 + level * 2;
        this.stats.spellMaxDamage = 5 + level * 3;
        this.stats.spellMana = 2 + 2 * level;
        this.stats.spellRange = level > 10 ? 10 : 8;

        gameLog("You have learnt level " + level + " " + this.stats.spellName + "!");
        gameLog("Range: " + this.stats.spellRange);
        gameLog("Damage: " + this.stats.spellMinDamage + "-" + this.stats.spellMaxDamage);
      }

      this.stats.mana = this.stats.maxMana;
    };
  }

  return Player;

});
