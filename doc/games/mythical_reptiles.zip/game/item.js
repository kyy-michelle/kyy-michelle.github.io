define(function(require) {

  function Item(game, col, row) {
    this.game = game;

    this.col = col;
    this.row = row;

    var pickType = function() {
      var types = [
        {
          chance: 0.13,
          type: "spell-fire"
        },
        {
          chance: 0.13,
          type: "spell-water"
        },
        {
          chance: 0.20,
          type: "strength-potion"
        },
        {
          chance: 0.34,
          type: "health-potion"
        },
        {
          chance: 0.20,
          type: "mana-potion"
        }
      ];

      var p = Math.random(),
          accum = 0;
      for (var i in types) {
        var x = types[i];
        if (p < accum + x.chance) {
          return x.type;
        }
        accum += x.chance;
      }
    };

    this.type = pickType();

    if (this.type == "health-potion") {
      gameLog("You discover a health potion!");
    } else if (this.type == "mana-potion") {
      gameLog("You discover a mana potion!");
    } else if (this.type == "strength-potion") {
      gameLog("You discover a strength potion!");
    } else if (this.type == "spell-fire") {
      gameLog("You discover a Fire spell book!");
    } else if (this.type == "spell-water") {
      gameLog("You discover a Water spell book!");
    }

    this.tick = function() {
      var player = this.game.player;

      if (player.col == this.col && player.row == this.row) {
        if (this.type == "health-potion") {
          player.stats.health = player.stats.maxHealth;
          gameLog("You feel replenished.");
        } else if (this.type == "mana-potion") {
          player.stats.mana = player.stats.maxMana;
          gameLog("You feel revitalised.");
        } else if (this.type == "strength-potion") {
          player.stats.attackMinDamage += 3;
          player.stats.attackMaxDamage += 5;
          gameLog("You grow stronger.");
          gameLog("Damage: " + player.stats.attackMinDamage + "-" + player.stats.attackMaxDamage);
        } else if (this.type == "spell-fire") {
          player.giveSpell("fire");
        } else if (this.type == "spell-water") {
          player.giveSpell("water");
        }

        this.game.player.stats.itemsFound += 1;
        this.game.player.updateStatsUI();

        var i = this.game.objects.indexOf(this);
        this.game.objects.splice(i, 1);
      }
    };

    this.draw = function(ctx) {
      var img = document.getElementById("item-" + this.type);
      ctx.drawImage(img, 0, 0, 50, 50, -12.5, -12.5, 25, 25);
    };
  }

  return Item;

});

