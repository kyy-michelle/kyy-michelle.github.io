define(function(require) {

  var Game = require("./game");

  var canvas = document.getElementById("game");

  window.Key   = require("./key")(window);
  window.Mouse = require("./mouse")(canvas, window);

  window.gameLog = function(msg) {
    var log = document.getElementById("text_log");
    log.innerHTML += msg + "<br>";
    log.scrollTop = log.scrollHeight;
  };

  function init() {
    var game = new Game(canvas);
    game.start();
  }

  window.onload = function() {
    init();
  };
  if (document.readyState == "complete"){ 
    init();
  }

});
