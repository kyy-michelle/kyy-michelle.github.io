define(function(require) {

  var Monster = require("./monster.js"),
      Item    = require("./item.js");

  function Container(game, col, row) {
    this.game = game;

    this.col = col;
    this.row = row;

    this.type = Math.random() < 0.4 ? "cave" : "chest";

    this.tick = function() {
      var player = this.game.player;
      var dist = this.game.manDistance(this.col, this.row, player.col, player.row);
      if (dist <= 1) {

        if (this.type == "cave") {
          // if it's a cave, enter battle
          var monster = new Monster(this.game, this.col, this.row);
          monster.randomiseStats(player.stats.level);
          this.game.enterBattleMode(monster);
        } else {
          var item = new Item(this.game, this.col, this.row);
          this.game.objects.unshift(item);
        }

        var i = this.game.objects.indexOf(this);
        this.game.objects.splice(i, 1);
      }
    };

    this.draw = function(ctx) {
      var img = document.getElementById(this.type);
      ctx.drawImage(img, -25, -25);
    };
  }

  return Container;

});
