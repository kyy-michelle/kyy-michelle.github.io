define(function(require) {

  return function(dom) {

    var Key = {};

    var pressed = {};
    dom.addEventListener("keydown", function(e) {
      pressed[e.keyCode] = true;
    });
    dom.addEventListener("keyup", function(e) {
      pressed[e.keyCode] = false;
    });

    Key.isDown = function(key) {
      return pressed[key] || false;
    };

    for (var c = 65; c <= 90; ++c) {
      Key[String.fromCharCode(c)] = c;
    }
    for (var c = 48; c <= 57; ++c) {
      Key[String.fromCharCode(c)] = c;
    }

    Key.BACKSPACE = 8;
    Key.TAB = 9;
    Key.ENTER = 13;
    Key.SHIFT = 16;
    Key.CONTROL = 17;
    Key.ESC = 27;
    Key.SPACE = 32;
    Key.PGUP = 33;
    Key.PGDN = 34;
    Key.END = 35;
    Key.HOME = 36;
    Key.LEFT = 37;
    Key.UP = 38;
    Key.RIGHT = 39;
    Key.DOWN = 40;
    Key.INSERT = 45;
    Key.DELETE = 46;
    Key[";"] = 186;
    Key["="] = 187;
    Key["-"] = 189;
    Key["/"] = 191;
    Key["`"] = 192;
    Key["["] = 219;
    Key["\\"] = 220;
    Key["]"] = 221;
    Key["\""] = 222;
    Key[","] = 188;
    Key["."] = 190;
    Key["/"] = 191;

    return Key;

  };

});
