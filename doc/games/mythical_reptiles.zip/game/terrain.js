define(function(require) {

  function Terrain(game) {

    this.game = game;

    this.generate = function() {
      var rows  = this.game.rows,
          cols  = this.game.cols,
          tiles = this.game.tiles;

      // basic initialization makes some sparse trees and mountains
      for (var x = 0; x < cols; ++x) {
        for (var y = 0; y < rows; ++y) {
          if (Math.random() < 0.03) {
            tiles[x][y].terrain = "tree";
          } else if (Math.random() > 0.98) {
            tiles[x][y].terrain = "mountain";
          } else {
            tiles[x][y].terrain = "grass";
          }
        }
      }

      var chance = 0;
      var improvement = 30; // a value to detail how the chance improves based
                            // upon it's surroundings
      // methods for generating mountain ranges builds top-left to bottom-right
      // mountain ranges
      for (var x = 1; x < cols - 1; ++x) {
        for (var y = 1; y < rows - 1; ++y) {
          if (tiles[x - 1][y].terrain == "mountain") {
            chance = chance + improvement;

          }
          if (tiles[x][y - 1].terrain == "mountain") {
            chance = chance + improvement;
       
          }
          if (tiles[x + 1][y].terrain == "mountain") {
            chance = chance + improvement;

          }
          if (tiles[x][y + 1].terrain == "mountain") {
            chance = chance + improvement;

          }

          if (Math.random() < (chance / 100)) {
            tiles[x][y].terrain = "mountain";

          }
          chance = 0;

        }
      }

      // builds top-right to bottom-left mountain ranges
      // can intersect with previous method to create crossing mountain ranges
      // can tweak improvement to alter the effects of surroundings
      for (var x = cols - 2; x > 1; --x) {
        for (var y = 1; y < rows - 1; ++y) {
          if (tiles[x + 1][y].terrain == "mountain") {
            chance = chance + improvement;

          }
          if (tiles[x][y - 1].terrain == "mountain") {
            chance = chance + improvement;
       
          }
          if (tiles[x - 1][y].terrain == "mountain") {
            chance = chance + improvement;

          }
          if (tiles[x][y + 1].terrain == "mountain") {
            chance = chance + improvement;

          }
          if (Math.random() < (chance / 100)) {
            tiles[x][y].terrain = "mountain";

          }
          chance = 0;

        }
      }
    
      //used to initialize lakes
      //allows for 5 lakes at maximum of decreasing size low probability of
      //small pools of water
      var terr = "water"
      var maxSize = 5;
      //generates size number of lakes and then forests
      //incredibly messy any ideas on how to clean it up
      //I can't think of a neat way of expressing this in javascript
      for (var type = 0; type < 2; type++) {
        if (type == 1) {
          terr = "tree" // reuses code toggles between forests and lakes
          maxSize = 9;  // allows for more forests of decreasing max sizes
        }               // forests can be isolated structures with low density

        // messiest pot of leprechaun magic
        // generates random points to build lakes/forests at
        // iteratively expands on the lakes/forests at decreasing probability.
        for (var size = 1; size < maxSize; size++) {
          var x = Math.floor(Math.random() * cols);
          while ((x > cols - 10) || (x < 10)) {
            x = Math.floor(Math.random() * cols);
          }
          var y = Math.floor(Math.random() * rows);
          while ((y > rows - 10) || (y < 10)) {
            y = Math.floor(Math.random() * rows);
          }

          //iterative expansion
          //if the tile is of the appropriate terrain (water/tree respectively)
          //it expands it's neighbours
          //until either it can't find a neighbour connected to water/tree
          //in it's size, or it dies due to probability
          tiles[x][y].terrain = terr;
          for (var b = 0; b < 10 - size; b++) {
            for (var h = 0; h < 10 - size; h++) {
              if (tiles[x + b][y + h].terrain == terr) {
                if (Math.random() < 0.95 - (b * 0.1 * size)) {
                  tiles[x + b + 1][y + h].terrain = terr;
                  tiles[x + b - 1][y + h].terrain = terr;
                  tiles[x + b][y + h + 1].terrain = terr;
                  tiles[x + b][y + h - 1].terrain = terr;
                }

              }

              if (tiles[x - b][y + h].terrain == terr) {
                if (Math.random() < 0.95 - (b * 0.1 * size)) {
                  tiles[x - b - 1][y + h].terrain = terr;
                  tiles[x - b + 1][y + h].terrain = terr;
                  tiles[x - b][y + h + 1].terrain = terr;
                  tiles[x - b][y + h - 1].terrain = terr;
                }

              }

              if (tiles[x + h][y + b].terrain == terr) {
                if (Math.random() < 0.95 - (b * 0.1 * size)) {
                  tiles[x + h][y + b + 1].terrain = terr;
                  tiles[x + h][y + b - 1].terrain = terr;
                  tiles[x + h + 1][y + b].terrain = terr;
                  tiles[x + h - 1][y + b].terrain = terr;
                }
              }
              if (tiles[x + h][y - b].terrain == terr) {
                if (Math.random() < 0.95 - (b * 0.1 * size)) {
                  tiles[x + h][y - b - 1].terrain = terr;
                  tiles[x + h][y - b + 1].terrain = terr;
                  tiles[x + h + 1][y - b].terrain = terr;
                  tiles[x + h - 1][y - b].terrain = terr;
                }

              }


            }
          }
          // end of inner for loops
        }
        //end of size for loop

      }

    };

    this.drawTile = function(type) {
      var ctx = this.game.ctx,
          tw  = this.game.tileWidth,
          th  = this.game.tileHeight;

      var img = document.getElementById("terrain-" + type);
      ctx.drawImage(img, 0, 0, tw, th, 0, 0, tw, th);
    };

  }

  return Terrain;

});
