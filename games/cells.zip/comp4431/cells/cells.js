// gameplay vars
var MAX_WIDTH = 600;
var MAX_HEIGHT = 450;
var BORDER = 20;
var SPEED = 3;
var FPS = 30;
// enemy vars
var MAX_ENEMIES = 25;
var enemies = new Array();
var enemy_max_size = 50;
// game vars
var MAX_SCORE = 50000;
var score = 0;
var score_flag = 1000; //enemy_max_size grows when score >= score_flag
var gameEnd = false;
var endMessage = "G a m e  O v e r !  S c o r e :  ";

var playerStuck = 0;
var player = new sprite(MAX_WIDTH/2,
                   MAX_HEIGHT/2,
                   10,
                   8,
                   "rgb(135,206,250)",
                   "rgb(99,184,255)");

// setting up the canvas...
var canvas = document.getElementById("game_canvas");
var ctxt = canvas.getContext("2d");
canvas.width = MAX_WIDTH;
canvas.height = MAX_HEIGHT;
canvas.addEventListener("mousemove", function(e) { //track mouse movement
      if (playerStuck > 0) { // if player collided with wall, then deduct counter
         playerStuck--;
      } else { // else read moouse move as normal
         var rect = canvas.getBoundingClientRect();
         player.x = e.clientX - rect.left;
         player.y = e.clientY - rect.top;
      }
   },false);

// enemy spawn loop
var spawnItvl = setInterval(function(){spawnEnemy()},Math.floor((Math.random()*5)+1)*300);  
// game loop
setInterval(function() {
   if (!gameEnd) {
      update();
      draw();
   } else {
      clearInterval(spawnItvl); //stop spawning enemies
      ctxt.font = "16px sans-serif";
      ctxt.fillStyle = "white";
      ctxt.fillText(endMessage + score,MAX_WIDTH/2-100,MAX_HEIGHT/2);
   }
}, 1000/FPS);

function update() {
   checkCollisions();
   moveEnemies();
   if (score >= score_flag) {
      enemy_max_size += 10;
      score_flag *= 2;
   } else if (score >= MAX_SCORE) {
      gameEnd = true;
      endMessage = "H o o r a y  Y o u  W o n !  S c o r e :  "
   }
}

function draw() {
   ctxt.fillStyle = "rgb(139,0,0)";
   ctxt.fillRect(0,0,MAX_WIDTH,MAX_HEIGHT);
   
   enemies.forEach(function(en) {
      en.draw();
   });
   
   ctxt.fillStyle = "rgb(255,246,143)";
   ctxt.fillRect(0,0,MAX_WIDTH,BORDER);
   ctxt.fillRect(0,MAX_HEIGHT-BORDER,MAX_WIDTH,BORDER);
   player.draw();
   
   ctxt.font = "bold 12px sans-serif";
   ctxt.fillStyle = "white";
   ctxt.fillText("Score: " + score,MAX_WIDTH-100,MAX_HEIGHT-40);
}

function checkCollisions() {
   var px = player.x;
   var py = player.y;
   var pr = player.size; //radius
   
   if ((playerStuck == 0 && py < 20) || (playerStuck == 0 && py > MAX_HEIGHT-BORDER)) {
      playerStuck = 2*FPS; // player stuck for 2 seconds when colliding with wall
   }
   
   enemies.forEach(function(en) { //check for enemy collisions
      var cx = px - en.x;
      var cy = py - en.y;
      var cr = pr - en.size;
      if ((cx*cx) + (cy*cy) <= 3*cr*cr) {
         if (en.size <= pr) {
            score += en.size*10;
            if (en.size > player.size/2) player.size++;
            enemies.splice(enemies.indexOf(en),1);
         } else {
            gameEnd = true;
         }
      }
   });
}

function spawnEnemy() {
   if (enemies.length < MAX_ENEMIES) {
      enemies[enemies.length] = new sprite(0,
                                       Math.floor((Math.random()*MAX_HEIGHT)+1),
                                       Math.floor((Math.random()*enemy_max_size)+3),
                                       SPEED,
                                       "black",
                                       "rgb(139,131,134)");
      }
}

function moveEnemies() {
   enemies.forEach(function(en) {
      en.x += SPEED;
      if (en.x > MAX_WIDTH) {
         enemies.splice(enemies.indexOf(en),1);
      }
      
      var rand = Math.floor(Math.random()*4);
      if (rand == 1 && en.y < MAX_HEIGHT) {
         en.y++;
      } else if (rand == 2 && en.y > 0) {
         en.y--;
      }
   });
}

function sprite(x,y,sz,spd,clr,bd) {
   this.x = x;
   this.y = y;
   this.size = sz;
   this.speed = spd;
   this.colour = clr;
   this.border = bd
   this.draw = draw;
   function draw() {
      ctxt.beginPath();
      ctxt.arc(this.x,this.y,this.size,0,Math.PI*2);
      ctxt.fillStyle = this.colour;
      ctxt.fill();
      ctxt.lineWidth = this.size/10;
      ctxt.strokeStyle = this.border;
      ctxt.stroke();
   }
}

